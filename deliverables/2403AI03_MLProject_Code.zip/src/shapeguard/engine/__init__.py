"""Training, checkpointing and inference."""
